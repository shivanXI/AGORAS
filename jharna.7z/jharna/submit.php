<img src="images/banner.jpg" alt="banner" id="pop"/>
class="main-banner"
<div class="main-banner"><img src="images/banner.jpg" alt="banner" id="pop"/>
	<!----begin------Insert to your webpage where you want to display the slider-->
        <div id='hislider1' style=" max-width:900px;  max-height:280px;height:100%; margin: 0 auto;">
        	
        	<noscript>The slider is powered by <strong>Hi Slider</strong>, a easy jQuery image slider from <a target="_blank" href="hislider.com">hislider.com</a>. Please enable JavaScript to view.</noscript><div class="hi-about-text" style="display:none">This jQuery slider was created with the free <a style="color:#FFF;" href="http://hislider.com" target="_blank">Hi Slider</a> for WordPress plugin,Joomla & Drupal Module from hislider.com.<br /><br /><a style="color:#FFF;" href="#" class="hi-about-ok">OK</a></div><div class="hi-slider-watermark"  style="display:none"><a href="http://hislider.com" target="_blank">hislider.com</a></div>
        </div>
      <!----end------Insert to your webpage where you want to display the slider--></div>